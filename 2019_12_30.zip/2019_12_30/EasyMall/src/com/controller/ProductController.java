package com.controller;

import com.po.Product;
import com.service.ProductService;
import com.service.ProductServiceImpl;
import com.vo.EasyUIResult;
import com.vo.Page;
import com.vo.SysResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService productService;

	
	
}
