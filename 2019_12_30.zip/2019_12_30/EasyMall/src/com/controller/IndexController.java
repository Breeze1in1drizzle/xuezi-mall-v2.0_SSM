package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * ������ɨ�跶Χ֮�ڣ����controller���󴴽�
 * ʵ��springmvc�����Ĺ��������߼�
 * @author TY
 * create date: 2019��5��20�� ����5:31:41
 */
@Controller("indexController")
@RequestMapping("/index")
public class IndexController {
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/regist")
	public String register() {
		return "regist";
	}
	
	@RequestMapping(value="/exit", method = RequestMethod.GET)
	public String exit(HttpSession session) {
		session.removeAttribute("user");
		return "forward:/index.jsp";
	}
	
	@RequestMapping(value="/toIndex", method = RequestMethod.GET)
	public String toIndex() {
		return "forward:/index.jsp";
	}

}
