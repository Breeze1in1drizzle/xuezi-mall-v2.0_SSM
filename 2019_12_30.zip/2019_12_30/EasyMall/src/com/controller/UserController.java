package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.po.User;
import com.service.UserService;

@Controller("userController")
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	

	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
		if(username == null || "".equals(username)){
			model.addAttribute("msg","�û�������Ϊ�գ�");
			return "login";
		}
		if(password == null || "".equals(password)){
			model.addAttribute("msg","���벻��Ϊ�գ�");
			return "login";
		}
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		User result = userService.login(user);
		if(result != null) {
			session.setAttribute("user", result);
			//����ǹ���Ա��¼�������̨
//			if(user.getUsername().equals("admin")) return "redirect:/admin/login";
			return "redirect:/index/toIndex";
		}else {
			model.addAttribute("msg","�û������������");
			return "login";
		}
	}
}
