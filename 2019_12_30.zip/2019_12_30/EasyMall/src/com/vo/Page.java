package com.vo;

import java.util.List;


public class Page {
  private Integer currentPage;
  private Integer totalPage;
  private List<?> products;
  
  public Integer getCurrentPage() {
     return this.currentPage;
  }
  public void setCurrentPage(Integer currentPage) {
     this.currentPage = currentPage;
  }
  public Integer getTotalPage() {
     return this.totalPage;
  }
  public void setTotalPage(Integer totalPage) {
     this.totalPage = totalPage;
  }
  public List<?> getProducts() {
     return this.products;
  }
  public void setProducts(List<?> products) {
     this.products = products;
  }
}
