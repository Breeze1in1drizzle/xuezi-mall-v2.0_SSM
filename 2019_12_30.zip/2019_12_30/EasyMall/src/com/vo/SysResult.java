package com.vo;

public class SysResult {
  private Integer status;
  
  public Integer getStatus() {
    return this.status;
  } private String msg; private Object data;
  public void setStatus(Integer status) {
    this.status = status;
  }
  public String getMsg() {
     return this.msg;
  }
  public void setMsg(String msg) {
     this.msg = msg;
  }
  public Object getData() {
     return this.data;
  }
  public void setData(Object data) {
    this.data = data;
  }

  
  public static SysResult build(Integer status, String msg, Object data) {
    SysResult result = new SysResult();
     result.setStatus(status);
    result.setMsg(msg);
    result.setData(data);
     return result;
  }
}
