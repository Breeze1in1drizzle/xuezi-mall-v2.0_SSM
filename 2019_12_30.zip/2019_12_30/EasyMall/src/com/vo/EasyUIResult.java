package com.vo;

/*import com.fasterxml.jackson.annotation.JsonProperty;*/
import java.util.List;

public class EasyUIResult {
	
	private Integer total;
	
	/*
	 * @JsonProperty("rows") private List<?> pList;
	 */
	
	public Integer getTotal() {
		return this.total;
	}
	
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	/*
	 * public List<?> getpList() { return this.pList; }
	 * 
	 * public void setpList(List<?> pList) { this.pList = pList; }
	 */
}
