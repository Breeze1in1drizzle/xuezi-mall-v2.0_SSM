package com.vo;public class PicUploadResult {
  private Integer width;
  private Integer height;
  private Integer error = Integer.valueOf(0);
  
  private String url;
  
  public Integer getError() {
	    return this.error;
  }
  public void setError(Integer error) {
	    this.error = error;
  }
  public Integer getWidth() {
 		return this.width;
  }
  public void setWidth(Integer width) {
		this.width = width;
  }
  public Integer getHeight() {
		return this.height;
  }
  public void setHeight(Integer height) {
		this.height = height;
  }
  public String getUrl() {
		return this.url;
  }
  public void setUrl(String url) {
		this.url = url;
  }
}
