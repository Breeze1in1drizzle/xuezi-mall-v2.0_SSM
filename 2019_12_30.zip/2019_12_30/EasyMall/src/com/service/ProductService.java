package com.service;

import java.util.List;
import java.util.UUID;

import com.po.Product;
import com.vo.EasyUIResult;
import com.vo.Page;

public interface ProductService {
	

	
	
}
