package com.service;

import com.dao.ProductDao;
import com.po.Product;
import com.vo.EasyUIResult;
import com.vo.Page;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDao productDao;



	
	
	
}
