package com.dao;

import com.po.Product;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("productDao")
@Mapper
public interface ProductDao {
	
	

}

