package com.service;

import java.util.List;

import com.po.User;


public interface UserService {
	public List<User> selectUserByUsername(User user);
	//�û�ע��
		void regist(User user);
		//�û���¼
		void login(String name, String password);

}
