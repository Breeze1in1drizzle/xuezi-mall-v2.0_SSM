package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.User;
import com.service.UserService;

@Controller("userController")
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/select")
	public String select(User user, Model model){		
		List<User> list = userService.selectUserByUsername(user);
		model.addAttribute("userList",list);
	//	return "/WEB-INF/jsp/userList.jsp";
		return "userList";
	}
	
	
	@RequestMapping("regist")
	public String regist(User user,Model model){
		
		System.out.println("�û�ע�᣺"+user.getUsername()+user.getPassword());
		
		user.setId(1);
		userService.regist(user);
		
		model.addAttribute("msg", "ע��ɹ�");
		//ע��ɹ�����תsuccess.jspҳ��
		return "success";
	}
	
	@RequestMapping("login")
	public String login(String name,String password,Model model){
		
		System.out.println("�û���¼��"+name+password);
		
		/*Map<String, String> map=new LinkedHashMap<String,String>();
		
		map.put("name", user.getName());
		map.put("password", user.getPassword());*/
		
		userService.login(name,password);
		
		model.addAttribute("msg", "��¼�ɹ�");
		
		return "success";
	}



}
